package com.poopmap.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.os.Bundle
import android.content.Context
import android.os.Looper
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.LocationSearching
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Brown = Color(0xFF7B4A2D)
private val Gray = Color(0xFF6B7280)

data class PoopPin(
    val id: String = UUID.randomUUID().toString(),
    val position: GeoPoint,
    val image: Bitmap,
    val time: Long = System.currentTimeMillis()
)

enum class Tab(val label: String) {
    POOPS("Poops"), MAP("Map"), SETTINGS("Settings"), CAMERA("Camera")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme { PoopMapApp() } }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun PoopMapApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(Tab.MAP) }
    val pins = remember { mutableStateListOf<PoopPin>() }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var myLocation by remember { mutableStateOf<GeoPoint?>(null) }
    var following by remember { mutableStateOf(false) }
    var didInitialZoom by remember { mutableStateOf(false) }
    var pendingFile by remember { mutableStateOf<File?>(null) }
    var hasLocation by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val poopIcon = remember { pinIcon(context) }
    val dotIcon = remember { userDotIcon() }
    val mapView = remember {
        Configuration.getInstance().apply {
            userAgentValue = context.packageName
            osmdroidBasePath = File(context.cacheDir, "osmdroid")
            osmdroidTileCache = File(context.cacheDir, "osmdroid/tiles")
        }
        MapView(context).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            isTilesScaledToDpi = true
            minZoomLevel = 2.0
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(2.5)
            controller.setCenter(GeoPoint(20.0, 0.0))
            // Dragging the map stops following
            setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_MOVE) following = false
                false
            }
        }
    }
    DisposableEffect(Unit) {
        mapView.onResume()
        onDispose { mapView.onPause(); mapView.onDetach() }
    }
    val pinList = pins.toList()
    val currentLoc = myLocation
    val selectedPin = pins.firstOrNull { it.id == selectedId }

    // Location permission
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        hasLocation = result.values.any { it }
    }
    LaunchedEffect(Unit) {
        if (!hasLocation) {
            permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    // Live location updates
    DisposableEffect(hasLocation) {
        if (!hasLocation) {
            onDispose { }
        } else {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000L).build()
            val callback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let { myLocation = GeoPoint(it.latitude, it.longitude) }
                }
            }
            client.requestLocationUpdates(request, callback, Looper.getMainLooper())
            onDispose { client.removeLocationUpdates(callback) }
        }
    }

    // First fix: zoom out to country level
    LaunchedEffect(myLocation != null) {
        val loc = myLocation ?: return@LaunchedEffect
        if (!didInitialZoom) {
            didInitialZoom = true
            mapView.controller.animateTo(loc, 5.0, 1200L)
        }
    }

    // Follow mode
    LaunchedEffect(myLocation, following) {
        val loc = myLocation ?: return@LaunchedEffect
        if (following) mapView.controller.animateTo(loc)
    }

    // Camera
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val file = pendingFile
        if (success && file != null) {
            val loc = myLocation
            val bmp = decodeScaled(file)
            if (loc == null) {
                Toast.makeText(context, "Waiting for location, try again", Toast.LENGTH_SHORT).show()
            } else if (bmp != null) {
                val pin = PoopPin(position = loc, image = bmp)
                pins.add(pin)
                selectedId = pin.id
            }
        }
        file?.delete()
        tab = Tab.MAP
    }

    fun launchCamera() {
        val dir = File(context.cacheDir, "images").apply { mkdirs() }
        val file = File.createTempFile("poop_", ".jpg", dir)
        pendingFile = file
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        cameraLauncher.launch(uri)
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { mapView },
            update = { mv ->
                mv.overlays.clear()
                mv.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
                    override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean {
                        selectedId = null
                        return true
                    }
                    override fun longPressHelper(p: GeoPoint?): Boolean = false
                }))
                pinList.forEach { pin ->
                    val m = Marker(mv)
                    m.position = pin.position
                    m.icon = poopIcon
                    m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    m.setInfoWindow(null)
                    m.setOnMarkerClickListener { _, _ -> selectedId = pin.id; true }
                    mv.overlays.add(m)
                }
                currentLoc?.let { loc ->
                    val m = Marker(mv)
                    m.position = loc
                    m.icon = dotIcon
                    m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    m.setInfoWindow(null)
                    m.setOnMarkerClickListener { _, _ -> true }
                    mv.overlays.add(m)
                }
                mv.invalidate()
            }
        )

        when (tab) {
            Tab.POOPS -> RecentPoopsScreen(pins) { pin ->
                selectedId = pin.id
                tab = Tab.MAP
                following = false
                mapView.controller.animateTo(pin.position, 17.0, 800L)
            }
            Tab.SETTINGS -> SettingsScreen()
            else -> {}
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
            if (tab == Tab.MAP) {
                Row(
                    Modifier.fillMaxWidth().padding(end = 16.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    LocationButton(following) {
                        val loc = myLocation
                        if (!hasLocation) {
                            permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        } else if (loc == null) {
                            Toast.makeText(context, "Waiting for location…", Toast.LENGTH_SHORT).show()
                        } else {
                            following = true
                            mapView.controller.animateTo(loc, 17.0, 600L)
                        }
                    }
                }
                selectedPin?.let { pin ->
                    SelectedPinCard(pin) { selectedId = null }
                }
            }
            BottomBar(tab) { clicked ->
                if (clicked == Tab.CAMERA) launchCamera() else tab = clicked
            }
        }
    }
}

@Composable
fun LocationButton(following: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = Color.White,
        shadowElevation = 6.dp,
        modifier = Modifier.size(48.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = if (following) Icons.Filled.MyLocation else Icons.Filled.LocationSearching,
                contentDescription = "My location",
                tint = Color(0xFF1A73E8)
            )
        }
    }
}

@Composable
fun SelectedPinCard(pin: PoopPin, onDismiss: () -> Unit) {
    val image = remember(pin.id) { pin.image.asImageBitmap() }
    val date = remember(pin.time) {
        SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(pin.time))
    }
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color.White.copy(alpha = 0.94f),
        shadowElevation = 6.dp,
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount -> if (dragAmount > 15f) onDismiss() }
            }
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(58.dp).clip(RoundedCornerShape(14.dp))
            )
            Column(Modifier.padding(start = 12.dp)) {
                Text("\uD83D\uDCA9 Logged Spot", fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Color.Black)
                Text(date, fontSize = 12.sp, color = Gray)
            }
        }
    }
}

@Composable
fun RecentPoopsScreen(pins: List<PoopPin>, onSelect: (PoopPin) -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .padding(top = 12.dp, bottom = 100.dp)
    ) {
        Text(
            "Recent Poops",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(14.dp))
        if (pins.isEmpty()) {
            Text(
                "No photos yet. Tap the camera button to log one.",
                fontSize = 15.sp,
                color = Gray,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(pins.reversed(), key = { it.id }) { pin ->
                    val image = remember(pin.id) { pin.image.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 145.dp, height = 245.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelect(pin) }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Text("Settings", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(16.dp))
        Text("PoopMap 1.0", fontSize = 15.sp, color = Color.LightGray)
        Spacer(Modifier.height(8.dp))
        Text("Map data \u00A9 OpenStreetMap contributors", fontSize = 13.sp, color = Color.Gray)
    }
}

@Composable
fun BottomBar(selected: Tab, onClick: (Tab) -> Unit) {
    val shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .shadow(12.dp, shape)
            .background(Color.White, shape)
            .navigationBarsPadding()
            .padding(top = 10.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        Tab.values().forEach { t ->
            BarItem(t, t == selected, Modifier.weight(1f)) { onClick(t) }
        }
    }
}

@Composable
fun BarItem(tab: Tab, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color = if (selected) Brown else Gray
    val icon: ImageVector? = when (tab) {
        Tab.MAP -> Icons.Filled.Map
        Tab.SETTINGS -> Icons.Filled.Settings
        Tab.CAMERA -> Icons.Filled.CameraAlt
        Tab.POOPS -> null
    }
    Column(
        modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClick
        ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.height(28.dp), contentAlignment = Alignment.Center) {
            if (icon == null) {
                Text("\uD83D\uDCA9", fontSize = 22.sp, modifier = Modifier.alpha(if (selected) 1f else 0.55f))
            } else {
                Icon(icon, contentDescription = tab.label, tint = color, modifier = Modifier.size(26.dp))
            }
        }
        Text(
            tab.label,
            fontSize = 12.sp,
            color = color,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

private fun pinIcon(context: Context): Drawable {
    val size = 110
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.style = Paint.Style.FILL
    paint.color = 0xFF7B4A2D.toInt()
    c.drawCircle(size / 2f, size / 2f, size / 2f, paint)
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 5f
    paint.color = android.graphics.Color.WHITE
    c.drawCircle(size / 2f, size / 2f, size / 2f - 3f, paint)
    paint.style = Paint.Style.FILL
    paint.textSize = 58f
    paint.textAlign = Paint.Align.CENTER
    val y = size / 2f - (paint.descent() + paint.ascent()) / 2f
    c.drawText("\uD83D\uDCA9", size / 2f, y, paint)
    return BitmapDrawable(context.resources, bmp)
}

private fun userDotIcon(): Drawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(0xFF1A73E8.toInt())
    setStroke(7, android.graphics.Color.WHITE)
    setSize(46, 46)
}

private fun decodeScaled(file: File): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
    val bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: return null
    val rotation = try {
        when (ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
    } catch (e: Exception) { 0f }
    if (rotation == 0f) return bmp
    val m = Matrix().apply { postRotate(rotation) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}
